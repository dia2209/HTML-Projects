//Mobile menu toggle
            document.getElementById("mobile-icon").onclick = () => 
            document.getElementById("navigation-list").classList.toggle("mobile-active");
                        
            // Function to show only the selected section
            function showContent(sectionId) {
                document.getElementById("home").classList.add("hidden");
                document.getElementById("about").classList.add("hidden");
                document.getElementById("gallery").classList.add("hidden");
                document.getElementById("contact").classList.add("hidden");
                document.getElementById(sectionId).classList.remove("hidden");
            }   